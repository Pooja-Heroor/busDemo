package com.lti.br.core.services;

import java.util.ArrayList;

import com.lti.br.core.entities.Bus;
import com.lti.br.core.exceptions.BrException;

public interface BusService {
	public ArrayList<Bus> getBusList() throws BrException;
	public boolean createNewBus(Bus bus) throws BrException;
	public Bus getBusId(int busid) throws BrException; 
}
