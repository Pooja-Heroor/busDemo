package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.PassengerDao;
import com.lti.br.core.entities.Passenger;
import com.lti.br.core.exceptions.PassengerException;

@Service
public class PassengerServiceImpl implements PassengerService{

	@Autowired
	private PassengerDao dao;
	
	@Override
	public ArrayList<Passenger> getPassengerList() throws PassengerException {
		return dao.getPassengerList();
	}

	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public boolean insertPassenger(Passenger passenger) throws PassengerException {
		return dao.insertPassenger(passenger);
	}

	@Override
	public Passenger getPassengerId(int d) throws PassengerException {
		return dao.getPassengerId(d);
	}
}
