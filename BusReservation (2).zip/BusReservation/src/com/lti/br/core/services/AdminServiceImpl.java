package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.AdminDao;
import com.lti.br.core.entities.Admin;
import com.lti.br.core.exceptions.AdminException;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao dao;
	
	@Override
	public ArrayList<Admin> getAdminList() throws AdminException {
		return dao.getAdminList();
	}

	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public boolean insertnewStop(Admin admin) throws AdminException {
		return dao.insertnewStop(admin);
	}

	@Override
	public Admin getAdminId(int a) throws AdminException {
		return dao.getAdminId(a);
	}

}
