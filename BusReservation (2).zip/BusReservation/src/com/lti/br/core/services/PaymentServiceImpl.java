package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.br.core.daos.PaymentDao;
import com.lti.br.core.entities.Payment;
import com.lti.br.core.exceptions.PaymentException;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	private PaymentDao dao;

	@Override
	public ArrayList<Payment> getPaymentList() throws PaymentException {
		return dao.getPaymentList();
	}

	@Override
	public boolean createNewPayment(Payment payment) throws PaymentException {
		return dao.insertnewPayment(payment);
	}

	@Override
	public Payment gettransactionId(int transactionId) throws PaymentException {
		return dao.getTransactionId(transactionId);
	}

}
