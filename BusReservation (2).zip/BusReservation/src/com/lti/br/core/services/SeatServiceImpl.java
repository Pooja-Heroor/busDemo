package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.SeatDao;
import com.lti.br.core.entities.Seat;
import com.lti.br.core.exceptions.SeatException;

@Service
public class SeatServiceImpl implements SeatService{

	@Autowired
	private SeatDao dao;
	
	@Override
	public ArrayList<Seat> getSeatList() throws SeatException {
		return dao.getSeatList();
	}

	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public boolean insertnewSeat(Seat seat) throws SeatException {
		return dao.insertnewSeat(seat);
	}

	@Override
	public Seat getSeatId(int s) throws SeatException {
		return dao.getSeatId(s);
	}

}
