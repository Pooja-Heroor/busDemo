package com.lti.br.core.services;

import java.util.ArrayList;
import com.lti.br.core.entities.Passenger;
import com.lti.br.core.exceptions.PassengerException;

public interface PassengerService {
	public ArrayList<Passenger> getPassengerList() throws PassengerException;
	public boolean insertPassenger(Passenger passenger) throws PassengerException;
	public Passenger getPassengerId(int d) throws PassengerException;
}
