package com.lti.br.core.services;

import java.util.ArrayList;

import com.lti.br.core.entities.Payment;
import com.lti.br.core.exceptions.PaymentException;


public interface PaymentService {
	
	public ArrayList<Payment> getPaymentList() throws PaymentException;
	public boolean createNewPayment(Payment payment) throws PaymentException;
	public Payment gettransactionId(int transactionId) throws PaymentException;
}
