package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.br.core.daos.ScheduleDao;
import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.ScheduleException;

@Service
public class ScheduleServiceImpl implements ScheduleService {
	
	@Autowired
	private ScheduleDao dao;

	@Override
	public ArrayList<Schedule> getScheduleList() throws ScheduleException {
		return dao.getScheduleList();
	}

	@Override
	public boolean insertnewSchedule(Schedule schedule) throws ScheduleException {
		return dao.insertnewSchedule(schedule);
	};

	@Override
	public Schedule getScheduleId(int schdulId) throws ScheduleException {
		return dao.getScheduleId(schdulId);
	}

}
