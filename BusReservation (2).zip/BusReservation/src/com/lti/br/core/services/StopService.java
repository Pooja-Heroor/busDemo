package com.lti.br.core.services;

import java.util.ArrayList;

import com.lti.br.core.entities.Stops;
import com.lti.br.core.exceptions.StopsException;

public interface StopService {
	public ArrayList<Stops> getStopsList() throws StopsException;
	public boolean insertnewStop(Stops stops) throws StopsException;
	public Stops getStopId(int s) throws StopsException;
}
