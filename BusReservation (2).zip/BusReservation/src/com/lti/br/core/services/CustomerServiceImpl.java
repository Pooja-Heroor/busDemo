package com.lti.br.core.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.br.core.daos.CustomerDao;
import com.lti.br.core.entities.Bus;
import com.lti.br.core.entities.Customer;
import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.CustomerException;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao dao;
	
	@Override
	public ArrayList<Customer> getCustomerList() throws CustomerException {
		
		return dao.getCustomerList() ;
	}

	@Override
	public boolean createNewCustomer(Customer cust) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.insertnewCustomer(cust);
	}

	@Override
	public Customer getCustId(int custId) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.getCustId(custId);
	}

	@Override
	public int isAuthenticated(String userName, String password) throws CustomerException {
		return dao.isAuthenticated(userName, password);
	}

	@Override
	public List<Bus> fetchBySourceDest(Schedule schedule) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.fetchBySourceDest(schedule);
	}

	@Override
	public List<Schedule> fetchScheduleByBusId(int busid) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.fetchScheduleByBusId(busid);
	}

}
