package com.lti.br.core.services;

import java.util.ArrayList;

import com.lti.br.core.entities.Ticket;
import com.lti.br.core.exceptions.TicketException;

public interface TicketService {
	public ArrayList<Ticket> getTicketList() throws TicketException;
	public boolean insertnewTicket(Ticket ticket) throws TicketException;
	public Ticket getTicketId(int t) throws TicketException; 
}
