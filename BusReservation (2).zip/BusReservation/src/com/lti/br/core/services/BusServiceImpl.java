package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.BusDao;
import com.lti.br.core.entities.Bus;
import com.lti.br.core.exceptions.BrException;

@Service
public class BusServiceImpl implements BusService {
	
	@Autowired
	private BusDao dao;
	
	@Override
	public ArrayList<Bus> getBusList() throws BrException {
		// TODO Auto-generated method stub
		return dao.getBusList();
	}

	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public boolean createNewBus(Bus bus) throws BrException {
		
		return dao.insertNewBus(bus);
	}

	@Override
	public Bus getBusId(int busid) throws BrException {
		// TODO Auto-generated method stub
		return dao.getBusId(busid);
	}

}
