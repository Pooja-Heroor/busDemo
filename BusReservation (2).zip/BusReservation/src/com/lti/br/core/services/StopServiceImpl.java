package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.StopsDao;
import com.lti.br.core.entities.Stops;
import com.lti.br.core.exceptions.StopsException;

@Service
public class StopServiceImpl implements StopService {
	@Autowired
	private StopsDao dao;
	
	@Override
	public ArrayList<Stops> getStopsList() throws StopsException {
		return dao.getStopsList();
	}

	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public boolean insertnewStop(Stops stops) throws StopsException {
		return dao.insertnewStop(stops);
	}

	@Override
	public Stops getStopId(int st) throws StopsException {
		return dao.getStopId(st);
	}

}
