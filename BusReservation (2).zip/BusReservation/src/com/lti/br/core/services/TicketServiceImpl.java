package com.lti.br.core.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.TicketDao;
import com.lti.br.core.entities.Ticket;
import com.lti.br.core.exceptions.TicketException;

@Service
public class TicketServiceImpl implements TicketService {

	@Autowired
	private TicketDao dao;
	
	@Override
	public ArrayList<Ticket> getTicketList() throws TicketException {
		return dao.getTicketList();
	}
	
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public boolean insertnewTicket(Ticket ticket) throws TicketException {
		return dao.insertnewTicket(ticket);
	}

	@Override
	public Ticket getTicketId(int t) throws TicketException {
		return dao.getTicketId(t);
	}

}
