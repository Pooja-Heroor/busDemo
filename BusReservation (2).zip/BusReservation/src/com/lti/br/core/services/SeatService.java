package com.lti.br.core.services;

import java.util.ArrayList;

import com.lti.br.core.entities.Seat;
import com.lti.br.core.exceptions.SeatException;

public interface SeatService {
	public ArrayList<Seat> getSeatList() throws SeatException;
	public boolean insertnewSeat(Seat seat) throws SeatException;
	public Seat getSeatId(int s) throws SeatException; 
}
