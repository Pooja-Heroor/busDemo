package com.lti.br.core.daos;

import java.util.ArrayList;

import com.lti.br.core.entities.Ticket;
import com.lti.br.core.exceptions.TicketException;

public interface TicketDao {
	public ArrayList<Ticket> getTicketList() throws TicketException;
	public boolean insertnewTicket(Ticket ticket) throws TicketException;
	public Ticket getTicketId(int t) throws TicketException;
//	public Ticket getTicket(int custId) throws TicketException;
}
