package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.entities.Seat;
import com.lti.br.core.exceptions.SeatException;

@Repository
public class SeatDaoImpl implements SeatDao {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public ArrayList<Seat> getSeatList() throws SeatException {
		String query = "from Seat";
		Query qry = manager.createQuery(query);
		List<Seat> list = qry.getResultList();
		return (ArrayList<Seat>)list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertnewSeat(Seat seat) throws SeatException {
		manager.persist(seat);
		return true;
	}

	@Override
	public Seat getSeatId(int s) throws SeatException {
		return manager.find(Seat.class, s);
	}

}
