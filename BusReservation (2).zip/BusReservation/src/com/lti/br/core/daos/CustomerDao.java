package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.lti.br.core.entities.Customer;
import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.CustomerException;
import com.lti.br.core.entities.Bus;

public interface CustomerDao {

	public ArrayList<Customer> getCustomerList() throws CustomerException;
	public boolean insertnewCustomer(Customer  cust) throws CustomerException;
	public Customer getCustId(int custId) throws CustomerException; 
	public int isAuthenticated(String userName, String password) throws CustomerException;
	public List<Bus> fetchBySourceDest(Schedule schedule) throws CustomerException;
	public List<Schedule> fetchScheduleByBusId(int busid) throws CustomerException;
}
