package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.ScheduleException;


@Repository
public class ScheduleDaoImpl implements ScheduleDao {
	
	@PersistenceContext
	private EntityManager manager;

	@Override
	public ArrayList<Schedule> getScheduleList() throws ScheduleException {
		Query qry = manager.createQuery("from Schedule");
		List<Schedule> list = qry.getResultList();
		System.out.println(list);
		return (ArrayList<Schedule>)list;
	}
	
	@Transactional(propagation=Propagation.REQUIRED)

	@Override
	public boolean insertnewSchedule(Schedule schedule) throws ScheduleException {
		manager.persist(schedule);
		return true;	
		}

	@Override
	public Schedule getScheduleId(int schdulId) throws ScheduleException {
		return manager.find(Schedule.class, schdulId);
	}


}
