package com.lti.br.core.daos;

public class SearchDeatilsImpl implements SearchDetails {

}
