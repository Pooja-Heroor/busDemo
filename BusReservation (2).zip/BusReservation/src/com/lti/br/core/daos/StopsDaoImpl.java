package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.entities.Stops;
import com.lti.br.core.exceptions.StopsException;

@Repository
public class StopsDaoImpl implements StopsDao {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public ArrayList<Stops> getStopsList() throws StopsException {
		Query qry = manager.createQuery("from Stops");
		List<Stops> list = qry.getResultList();
		return (ArrayList<Stops>)list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertnewStop(Stops stops) throws StopsException {
		manager.persist(stops);
		return true;
	}

	@Override
	public Stops getStopId(int st) throws StopsException {
		return manager.find(Stops.class, st);
	}

}
