package com.lti.br.core.daos;

import java.util.ArrayList;

import com.lti.br.core.entities.*;
import com.lti.br.core.exceptions.*;


public interface PassengerDao {
	public ArrayList<Passenger> getPassengerList() throws PassengerException;
	public boolean insertPassenger(Passenger passenger) throws PassengerException;
	public Passenger getPassengerId(int d) throws PassengerException;  
}
