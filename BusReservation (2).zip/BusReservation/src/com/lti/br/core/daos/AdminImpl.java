package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.entities.Admin;
import com.lti.br.core.exceptions.AdminException;

@Repository
public class AdminImpl implements AdminDao {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public ArrayList<Admin> getAdminList() throws AdminException {
		Query qry = manager.createQuery("from Admin");
		List<Admin> list = qry.getResultList();
		return (ArrayList<Admin>)list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertnewStop(Admin admin) throws AdminException {
		manager.persist(admin);
		return true;
	}

	@Override
	public Admin getAdminId(int a) throws AdminException {
		return manager.find(Admin.class, a);
	}
	

}
