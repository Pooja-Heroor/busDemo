package com.lti.br.core.daos;

import java.util.ArrayList;

import com.lti.br.core.entities.Admin;
import com.lti.br.core.exceptions.AdminException;


public interface AdminDao {
	public ArrayList<Admin> getAdminList() throws AdminException;
	public boolean insertnewStop(Admin admin) throws AdminException;
	public Admin getAdminId(int a) throws AdminException; 
}
