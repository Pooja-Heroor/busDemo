package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.entities.Bus;
import com.lti.br.core.entities.Customer;
import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.CustomerException;


@Repository
public class CustomerDaoImpl implements CustomerDao {
	
	@PersistenceContext
	private EntityManager manager;

	@Override
	public ArrayList<Customer> getCustomerList() throws CustomerException{
			Query qry = manager.createQuery("from Customer");
			List<Customer> list = qry.getResultList();
			return (ArrayList<Customer>)list;
		
		}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertnewCustomer(Customer cust) throws CustomerException {
		manager.persist(cust);
		return true;
	}

	@Override
	public Customer getCustId(int custId) throws CustomerException {
		return manager.find(Customer.class, custId);
		
	}

	@Override
	public int isAuthenticated(String userName, String password) {
		
		String strQry ="select c from Customer c where c.userName =: userName and c.password=:password";

		try{
		Query qry = manager.createQuery(strQry);
		qry.setParameter("userName",userName);
		qry.setParameter("password",password);
		Customer customer = (Customer) qry.getSingleResult();
		System.out.println("--------------");
		System.out.println(customer.getCustName());
		System.out.println(customer.getPassword());
		
		if(customer.getPassword().equals(password)){
			return customer.getCustId();
		}
		
		else
			{
			return 0;
			}
		}
		catch(Exception e) {
			System.out.println("Wrong Details");
			throw e;
		}
			}

/*	@Override
	public List<Bus> fetchBySourceDest(Schedule schedule) throws CustomerException {
	String jpql ="select b from Bus b join b.schedules s  where s.source =:source and s.destination =:destination";
	  Query qry = manager.createQuery(jpql);
	  List<Bus> bus1=qry.getResultList();
	  return bus1;
	  
	}*/

	@Override
	public List<Bus> fetchBySourceDest(Schedule schedule)throws CustomerException {
		//String hql = "select a from Album a inner join a.songs s where s.artist=:ar";
		/*Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(schedule.getDateBook().getDate());
		System.out.println("Calendar: " + cal);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date myDate = new java.sql.Date(cal.getTime().getTime());
        System.out.println("After conversion: " + myDate);*/
        
		String jpql ="select b from Bus b join b.schedules s where s.source = :source and s.destination = :destination"; // and s.dateBook =:dateBook
		 Query qry = manager.createQuery(jpql);
		 List<Bus> busListOnSchedule = new ArrayList<>();
		 
		 qry.setParameter("source", schedule.getSource());
		 qry.setParameter("destination", schedule.getDestination());
		 List<Bus> list = qry.getResultList();
		 //System.out.println("From table: " + list.get(0).getSchedules());
		 System.out.println("helllo");
		 for(Bus bus : list){
			 for (Schedule schedules : bus.getSchedules()){
				 Calendar schCal = Calendar.getInstance();
				 schCal.setTime( schedules.getDateBook());
				 Calendar busCal = Calendar.getInstance();
				 busCal.setTime(schedule.getDateBook());
				 
				 System.out.println("Schedule: " );
				 int schDay = schCal.get(Calendar.DAY_OF_MONTH);
				 int schMon = schCal.get(Calendar.MONTH);
				 int schYer = schCal.get(Calendar.YEAR);
				 System.out.println(schDay + " " + schMon +  " " + schYer);
				 
				 System.out.println("Bus: " );
				 int busDay = busCal.get(Calendar.DAY_OF_MONTH);
				 int busMon = busCal.get(Calendar.MONTH);
				 int busYer = busCal.get(Calendar.YEAR);
				 System.out.println(busDay + " " + busMon +  " " + busYer);
				 if ((schDay == busDay) && (schMon == busMon) && (schYer == busYer)){
					 System.out.println("Matched.");
					 busListOnSchedule.add(bus);
				 }
			 }
		 }
		System.out.println(busListOnSchedule);
		  return list;
	
		}

	@Override
	public List<Schedule> fetchScheduleByBusId(int busid) throws CustomerException {
		

		String jpql = "select s from Schedule s  inner join s.bus b  where b.busid =:busid";
		 Query qry = manager.createQuery(jpql);
		qry.setParameter("busid",busid);
		List<Schedule> list = qry.getResultList();
		return list;
		 
//		return (List<Schedule>) manager.find(Schedule.class, busid);
	
	}

}



