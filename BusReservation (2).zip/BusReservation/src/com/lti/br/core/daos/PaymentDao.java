package com.lti.br.core.daos;

import java.util.ArrayList;

import com.lti.br.core.entities.Payment;
import com.lti.br.core.exceptions.PaymentException;

public interface PaymentDao {
	
	public ArrayList<Payment> getPaymentList() throws PaymentException;
	public boolean insertnewPayment(Payment  payment) throws PaymentException;
	public Payment getTransactionId(int transactionId) throws PaymentException; 

}
