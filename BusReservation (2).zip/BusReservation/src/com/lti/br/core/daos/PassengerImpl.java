package com.lti.br.core.daos;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.daos.*;
import com.lti.br.core.entities.*;
import com.lti.br.core.exceptions.PassengerException;

@Repository
public class PassengerImpl implements PassengerDao {
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public ArrayList<Passenger> getPassengerList() throws PassengerException {
		String query = "from Passenger";
		Query qry = manager.createQuery(query);
		List<Passenger> list = qry.getResultList();
		return (ArrayList<Passenger>)list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertPassenger(Passenger passenger) throws PassengerException {
		manager.persist(passenger);
		return true;
	}

	@Override
	public Passenger getPassengerId(int d) throws PassengerException {
		return manager.find(Passenger.class, d);
	}

}
