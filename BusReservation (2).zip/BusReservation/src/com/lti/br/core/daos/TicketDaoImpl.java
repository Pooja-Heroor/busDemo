package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.lti.br.core.entities.Ticket;
import com.lti.br.core.exceptions.TicketException;

@CrossOrigin
@Repository
public class TicketDaoImpl implements TicketDao {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public ArrayList<Ticket> getTicketList() throws TicketException {
		Query qry = manager.createQuery("from Ticket");
		List<Ticket> list = qry.getResultList();
		return (ArrayList<Ticket>)list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertnewTicket(Ticket ticket) throws TicketException {
		manager.persist(ticket);
		return true;
	}

	@Override
	public Ticket getTicketId(int t) throws TicketException {
		return manager.find(Ticket.class, t);
	}

//	@Override
//	public Ticket getTicket(int custId) throws TicketException {
//		String strQry ="select t from Ticket t where t.customerId =:custId";
//		return null;
//	}

}
