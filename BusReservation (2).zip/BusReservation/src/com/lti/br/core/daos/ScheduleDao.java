package com.lti.br.core.daos;

import java.util.ArrayList;

import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.ScheduleException;


public interface ScheduleDao {
	
	public ArrayList<Schedule> getScheduleList() throws ScheduleException;
	public boolean insertnewSchedule(Schedule schedule) throws ScheduleException;
	public Schedule getScheduleId(int schdulId) throws ScheduleException; 

}
