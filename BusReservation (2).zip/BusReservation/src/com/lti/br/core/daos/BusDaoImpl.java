package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.br.core.entities.Bus;
import com.lti.br.core.exceptions.BrException;


@Repository
public class BusDaoImpl implements BusDao {
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public ArrayList<Bus> getBusList() throws BrException {
		/*String query = "from Bus";*/
		Query qry = manager.createQuery("from Bus");
		List<Bus> list = qry.getResultList();
		return (ArrayList<Bus>) list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertNewBus(Bus bus) throws BrException {
		manager.persist(bus);
		return true;
	}

	@Override
	public Bus getBusId(int busid) throws BrException {
		// TODO Auto-generated method stub
		return manager.find(Bus.class, busid);

	}

}
