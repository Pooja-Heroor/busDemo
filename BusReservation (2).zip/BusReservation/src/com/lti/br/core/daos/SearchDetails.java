package com.lti.br.core.daos;

public interface SearchDetails {

}
