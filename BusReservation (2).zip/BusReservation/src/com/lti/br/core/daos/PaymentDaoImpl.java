package com.lti.br.core.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.lti.br.core.entities.Payment;
import com.lti.br.core.exceptions.PaymentException;

@Repository
public class PaymentDaoImpl implements PaymentDao {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public ArrayList<Payment> getPaymentList() throws PaymentException {
		Query qry = manager.createQuery("from Payment");
		List<Payment> list = qry.getResultList();
		return (ArrayList<Payment>)list;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean insertnewPayment(Payment payment) throws PaymentException {
		manager.persist(payment);
		return true;
	}

	@Override
	public Payment getTransactionId(int transactionId) throws PaymentException {
		return manager.find(Payment.class, transactionId);
	}
}
