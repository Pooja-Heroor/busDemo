package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.ScheduleException;
import com.lti.br.core.services.ScheduleService;

@CrossOrigin
@RestController
public class ScheduleController {
	
	@Autowired
	private ScheduleService services;
	

	
	@GetMapping(value="/scheduleList", produces="application/json")
	public @ResponseBody List<Schedule> getScheduleList(){
		ArrayList<Schedule> ScheduleList=null;
		try {
			ScheduleList = services.getScheduleList();
		} catch (ScheduleException e) {
			e.printStackTrace();
		}
		return ScheduleList;
	}
	
	@PostMapping(value="/addSchedule",consumes="application/json")
	public void insertnewSchedule(@RequestBody Schedule schedule){
		System.out.println(schedule);
		try {
			services.insertnewSchedule(schedule);
		} catch (ScheduleException e) {
			e.printStackTrace();
		}
	}
	
	
	@PutMapping(value="/fetchSchedule", consumes="application/json")
	public @ResponseBody Schedule getScheduleId(@RequestBody int schdulId) throws ScheduleException{
		return services.getScheduleId(schdulId);
	}	
}
