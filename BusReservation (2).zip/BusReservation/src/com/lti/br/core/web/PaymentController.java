package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.lti.br.core.entities.Payment;
import com.lti.br.core.exceptions.PaymentException;
import com.lti.br.core.services.PaymentService;

@CrossOrigin
@RestController
public class PaymentController {
	
	@Autowired
	private PaymentService services;
	
	@GetMapping(value="/paymentList", produces="application/json")
	public @ResponseBody List<Payment> getPaymentList(){
		ArrayList<Payment> paymentList=null;
		try {
			paymentList = services.getPaymentList();
		} catch (PaymentException e) {
			e.printStackTrace();
		}
		return paymentList;
	}
	
	@PostMapping(value="/addPayment",consumes="application/json")
	public void getPaymentList(@RequestBody Payment payment){
		System.out.println(payment);
		try {
			services.createNewPayment(payment);
		} catch (PaymentException e) {
			e.printStackTrace();
		}
	}
	
	@PutMapping(value="/fetchPayment", consumes="application/json")
	public @ResponseBody Payment gettransactionId(@RequestBody int transactionId) throws PaymentException{
		return services.gettransactionId(transactionId);
	}

}
