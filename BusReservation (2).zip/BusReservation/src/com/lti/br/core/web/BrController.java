package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.br.core.entities.Bus;
import com.lti.br.core.exceptions.BrException;
import com.lti.br.core.services.BusService;

/*
 * need to do autowiring with the service layar
 */

// http://localhost:8081/SpringMVC130_REST/deptList     //url to identified the project
@RestController    //publish as REST service
@CrossOrigin
public class BrController {
	
	@Autowired                  // to avoid null pointer exception
	private BusService services;
	
	@GetMapping(value="/busList", produces="application/json")
	public @ResponseBody List<Bus> getBusList(){
		ArrayList<Bus> busList=null;
		try {
			busList = services.getBusList();
		} catch (BrException e) {
			e.printStackTrace();
		}
		return busList;
	}
	
	/*@RequestMapping(name="/deptList", produces="application/json", method=RequestMethod.GET)
	public ArrayList<Department> getDeptList(){
		ArrayList<Department> deptList=null;
		try {
			deptList = services.getDeptList();
		} catch (HrException e) {
			e.printStackTrace();
		}
		return deptList;
	}*/
	
	
	//insert data in the dept we use postMapping 
	//this method receive json as input 
	@PostMapping(value="/addBus",consumes="application/json")
	public void getDeptList(@RequestBody Bus bus){
		System.out.println(bus);
		try {
			services.createNewBus(bus);
		} catch (BrException e) {
			e.printStackTrace();
		}
	}
	
	//put is used for fetching the data from table
	@PutMapping(value="/fetchBus", consumes="application/json")
	public @ResponseBody Bus getBusId(@RequestBody int busid) throws BrException{
		return services.getBusId(busid);
	}
}
