package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.lti.br.core.entities.Ticket;
import com.lti.br.core.exceptions.TicketException;
import com.lti.br.core.services.TicketService;

@RestController
@CrossOrigin

public class TicketController {

	@Autowired
	private TicketService services;
	
	@GetMapping(value="/ticketList", produces="application/json")
	public @ResponseBody List<Ticket> getTicketList(){
		ArrayList<Ticket> ticketList=null;
		try {
			ticketList = services.getTicketList();
		} catch (TicketException e) {
			e.printStackTrace();
		}
		return ticketList;
	}
	
	@PostMapping(value="/addTicket",consumes="application/json")
	public void getTicketList(@RequestBody Ticket ticket){
		System.out.println(ticket);
		try {
			services.insertnewTicket(ticket);
		} catch (TicketException e) {
			e.printStackTrace();
		}
	}
	
	@PutMapping(value="/fetchTicket", consumes="application/json")
	public @ResponseBody Ticket getTicketId(@RequestBody int t) throws TicketException{
		return services.getTicketId(t);
	}
}
