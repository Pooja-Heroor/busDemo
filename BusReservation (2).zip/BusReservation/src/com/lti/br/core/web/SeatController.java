package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.br.core.entities.Seat;
import com.lti.br.core.exceptions.SeatException;
import com.lti.br.core.services.SeatService;


@RestController
@CrossOrigin
public class SeatController {

	@Autowired
	private SeatService services;
	
	@GetMapping(value="/seatList", produces="application/json")
	public @ResponseBody List<Seat> getSeatList(){
		ArrayList<Seat> seatList=null;
		try {
			seatList = services.getSeatList();
		} catch (SeatException e) {
			e.printStackTrace();
		}
		System.out.println(seatList);
		return seatList;
	}
	
	@PostMapping(value="/addSeat",consumes="application/json")
	public void getSeatList(@RequestBody Seat seat){
		System.out.println(seat);
		try {
			services.insertnewSeat(seat);
		} catch (SeatException e) {
			e.printStackTrace();
		}
	}
	
	@PutMapping(value="/fetchSeat", consumes="application/json")
	public @ResponseBody Seat getSeatId(@RequestBody int s) throws SeatException{
		return services.getSeatId(s);
	}
}
