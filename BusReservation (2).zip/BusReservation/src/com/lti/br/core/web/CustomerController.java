package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.br.core.entities.Bus;
import com.lti.br.core.entities.Customer;
import com.lti.br.core.entities.Schedule;
import com.lti.br.core.exceptions.CustomerException;
import com.lti.br.core.services.CustomerService;


@RestController
@CrossOrigin
public class CustomerController {
	
	@Autowired
	private CustomerService services;
	
	@GetMapping(value="/custList", produces="application/json")
	public @ResponseBody List<Customer> getCustomerList(){
		ArrayList<Customer> customerList=null;
		try {
			customerList = services.getCustomerList();
		} catch (CustomerException e) {
			e.printStackTrace();
		}
		return customerList;
	}
	
	/*@RequestMapping(name="/deptList", produces="application/json", method=RequestMethod.GET)
	public ArrayList<Department> getDeptList(){
		ArrayList<Department> deptList=null;
		try {
			deptList = services.getDeptList();
		} catch (HrException e) {
			e.printStackTrace();
		}
		return deptList;
	}*/
	
	
	//insert data in the dept we use postMapping 
	//this method receive json as input 
	@PostMapping(value="/addCust",consumes="application/json")
	public void getDeptList(@RequestBody Customer cust){
		System.out.println(cust);
		try {
			services.createNewCustomer(cust);
		} catch (CustomerException e) {
			e.printStackTrace();
		}
	}
	
	//put is used for fetching the data from table
	@PutMapping(value="/fetchCust", consumes="application/json")
	public @ResponseBody Customer getCustId(@RequestBody int custId) throws CustomerException{
		return services.getCustId(custId);
	}	
	
	@PostMapping(value="/custLogin", consumes="application/json")
	public int custAuthentication(@RequestParam String userName, @RequestParam String password ) throws CustomerException{
		System.out.println(userName);
		return services.isAuthenticated(userName,password);
	}
	

	@PostMapping(value="/searchBus", consumes="application/json")
	public @ResponseBody List<Bus> searchBus(@RequestBody Schedule schedule) throws CustomerException{
		System.out.println(schedule.getSource());
		System.out.println(schedule.getDestination());
		System.out.println(schedule.getDateBook());
		return services.fetchBySourceDest(schedule);
		
	}
	
	@PutMapping(value="/searchSchedule", consumes="application/json")
	public @ResponseBody List<Schedule> searchSchedule (@RequestBody int busid) throws CustomerException{

		return services.fetchScheduleByBusId(busid);
}
}