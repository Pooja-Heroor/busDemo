package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.br.core.entities.Admin;
import com.lti.br.core.exceptions.AdminException;
import com.lti.br.core.services.AdminService;

@RestController
public class AdminController {
	@Autowired
	private AdminService services;
	
	//http://localhost:8989/BusReservation/adminList
	@GetMapping(value="/adminList", produces="application/json")
	public @ResponseBody List<Admin> getAdminsList(){
		ArrayList<Admin> adminsList=null;
		try {
			adminsList = services.getAdminList();
		} catch (AdminException e) {
			e.printStackTrace();
		}
		return adminsList;
	}
	
	//http://localhost:8989/BusReservation/addAdmin
	@PostMapping(value="/addAdmin",consumes="application/json")
	public void getStopsList(@RequestBody Admin admin){
		System.out.println(admin);
		try {
			services.insertnewStop(admin);
		} catch (AdminException e) {
			e.printStackTrace();
		}
	}
	
	//http://localhost:8989/BusReservation/fetchAdmin
	@PutMapping(value="/fetchAdmin", consumes="application/json")
	public @ResponseBody Admin getTicketId(@RequestBody int a) throws AdminException{
		return services.getAdminId(a);
	}
}
