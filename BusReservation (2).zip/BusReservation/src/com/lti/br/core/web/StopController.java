package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.br.core.entities.Stops;
import com.lti.br.core.exceptions.StopsException;
import com.lti.br.core.services.StopService;

@CrossOrigin
@RestController
public class StopController {

	@Autowired
	private StopService services;

	@GetMapping(value="/stopsList", produces="application/json")
	public @ResponseBody List<Stops> getStopsList(){
		ArrayList<Stops> stopsList=null;
		try {
			stopsList = services.getStopsList();
		} catch (StopsException e) {
			e.printStackTrace();
		}
		return stopsList;
	}
	
	@PostMapping(value="/addStops",consumes="application/json")
	public void getStopsList(@RequestBody Stops stops){
		System.out.println(stops);
		try {
			services.insertnewStop(stops);
		} catch (StopsException e) {
			e.printStackTrace();
		}
	}
	
	@PutMapping(value="/fetchStop", consumes="application/json")
	public @ResponseBody Stops getTicketId(@RequestBody int st) throws StopsException{
		return services.getStopId(st);
	}
}
