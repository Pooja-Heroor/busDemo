package com.lti.br.core.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.br.core.entities.Passenger;
import com.lti.br.core.exceptions.PassengerException;
import com.lti.br.core.services.PassengerService;

@RestController
@CrossOrigin
public class PassengerController {
	
	@Autowired
	private PassengerService services;
	
	@GetMapping(value="/passengerList", produces="application/json")
	public @ResponseBody List<Passenger> getDeptList(){
		ArrayList<Passenger> passengerList=null;
		try {
			passengerList = services.getPassengerList();
		} catch (PassengerException e) {
			e.printStackTrace();
		}
		return passengerList;
	}
	
	@PostMapping(value="/addPassenger",consumes="application/json")
	public void getDeptList(@RequestBody Passenger passenger){
		System.out.println(passenger);
		try {
			services.insertPassenger(passenger);
		} catch (PassengerException e) {
			e.printStackTrace();
		}
	}
	
	@PutMapping(value="/fetchPassenger", consumes="application/json")
	public @ResponseBody Passenger getDeptId(@RequestBody int d) throws PassengerException{
		return services.getPassengerId(d);
	}
}
