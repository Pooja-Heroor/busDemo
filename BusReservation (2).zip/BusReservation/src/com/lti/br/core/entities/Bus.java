package com.lti.br.core.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="BUS")
public class Bus {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_bus_seq")
	@SequenceGenerator(name = "my_bus_seq", sequenceName = "BUS_SEQ", allocationSize = 1)
	@Column(name="BUS_ID")
	private int busid;
	
	@Column(name="BUSNAME")
	private String busname;
	
	@Column(name="BUSTYPE")
	private String bustype;
	
	@Column(name="BUSNO")
	private int busno;
	
	@JsonIgnore
	@OneToMany(mappedBy="bus",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Schedule> schedules;

	public Bus() {
		// TODO Auto-generated constructor stub
	}

	public Bus(int busid, String busname, String bustype, int busno, List<Schedule> schedules) {
		super();
		this.busid = busid;
		this.busname = busname;
		this.bustype = bustype;
		this.busno = busno;
		this.schedules = schedules;
	}

	public int getBusid() {
		return busid;
	}

	public void setBusid(int busid) {
		this.busid = busid;
	}

	public String getBusname() {
		return busname;
	}

	public void setBusname(String busname) {
		this.busname = busname;
	}

	public String getBustype() {
		return bustype;
	}

	public void setBustype(String bustype) {
		this.bustype = bustype;
	}

	public int getBusno() {
		return busno;
	}

	public void setBusno(int busno) {
		this.busno = busno;
	}

	public List<Schedule> getSchedules() {
		return schedules;
	}

	public void setSchedules(List<Schedule> schedules) {
		this.schedules = schedules;
	}

	@Override
	public String toString() {
		return "Bus [busid=" + busid + ", busname=" + busname + ", bustype=" + bustype + ", busno=" + busno
				+ "]";
	}
	
	
	

	
	
	
	
	
	
	

}
