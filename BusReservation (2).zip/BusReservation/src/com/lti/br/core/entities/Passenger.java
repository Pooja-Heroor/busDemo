package com.lti.br.core.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PASSENGER")
public class Passenger {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_passenger_seq")
	@SequenceGenerator(name = "my_passenger_seq", sequenceName = "PASS_SEQ", allocationSize = 1)
	@Column(name="PASSENGER_ID")
	private int passengerId;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="AGE")
	private String age;
	
	@Column(name="GENDER")
	private String gender;
	
	@Column(name="BOOKING_ID")
	//@JoinColumn(name="BUS_ID")
	private int bookingId;
	
//	@ManyToOne(fetch=FetchType.EAGER)
//	@JoinColumn(name="CUST_ID")
//	private Customer customer;

	public Passenger() {
	}

	public Passenger(int passengerId, String name, String age, String gender, int bookingId, Customer customer) {
		super();
		this.passengerId = passengerId;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.bookingId = bookingId;
	
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	

	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", name=" + name + ", age=" + age + ", gender=" + gender
				+ ", bookingId=" + bookingId +  "]";
	}
	
	
	
}
