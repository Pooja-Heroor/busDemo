package com.lti.br.core.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.web.bind.annotation.CrossOrigin;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="SEAT")
public class Seat {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seat_seq")
	@SequenceGenerator(name = "my_seat_seq",sequenceName ="SEAT_SEQ", allocationSize = 1)
	@Column(name="SEAT_ID")
	private int seatId;
	
	@Column(name="SEAT_BOOKED_CUSTOMER")
	private int noOfSeatsBooked;
	
	@Column(name="CUST_ID")
	//@JoinColumn(name="CUST_ID")
	private int customerId;

	
	@Column(name="TOTAL_FARE")
	private double totalFare;
	
	
//	@Column(name="SCHEDULE_ID")
//	private int scheduleId;
	
	@Column(name="BUS_ID")
	private int busid;
	
	
//	@JsonIgnore
//	@OneToOne(mappedBy="seat",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
//	private Schedule schedule;

	
	public Seat() {
		// TODO Auto-generated constructor stub
	}


public Seat(int seatId, int noOfSeatsBooked, int customerId, double totalFare, int busid) {
	super();
	this.seatId = seatId;
	this.noOfSeatsBooked = noOfSeatsBooked;
	this.customerId = customerId;
	this.totalFare = totalFare;
	this.busid = busid;
}


public int getSeatId() {
	return seatId;
}


public void setSeatId(int seatId) {
	this.seatId = seatId;
}


public int getNoOfSeatsBooked() {
	return noOfSeatsBooked;
}


public void setNoOfSeatsBooked(int noOfSeatsBooked) {
	this.noOfSeatsBooked = noOfSeatsBooked;
}


public int getCustomerId() {
	return customerId;
}


public void setCustomerId(int customerId) {
	this.customerId = customerId;
}


public double getTotalFare() {
	return totalFare;
}


public void setTotalFare(double totalFare) {
	this.totalFare = totalFare;
}


public int getBusId() {
	return busid;
}


public void setBusId(int busid) {
	this.busid = busid;
}


@Override
public String toString() {
	return "Seat [seatId=" + seatId + ", noOfSeatsBooked=" + noOfSeatsBooked + ", customerId=" + customerId
			+ ", totalFare=" + totalFare + ", busid=" + busid + "]";
}


	
	


	
	
}
