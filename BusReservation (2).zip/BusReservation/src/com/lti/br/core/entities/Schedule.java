package com.lti.br.core.entities;

import java.sql.Date;
import java.time.LocalDate;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;



@Entity
@Table(name="SCHEDULE")

public class Schedule {
	
	@Id
	@Column(name="SCHEDULE_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_schedule_seq")
	@SequenceGenerator(name = "my_schedule_seq", sequenceName = "SCH_SEQ", allocationSize = 1)
	private int scdulID;

	
	@Column(name="DESTINATION")
	private String destination;
	
	@Column(name="DURATION")
	private int duratn;
	
	@Column(name="ARRIVAL_TIME")
	private int arriveTime;
	
	@Column(name="DEPARTURE_TIME")
	private int deparTime;
	
	@Column(name="TOTAL_SEAT")
	private int totSeat;
	
	@Column(name="BOOKED_SEAT")
	private int bookSeat;
	
	@Column(name="AVAILABLE_SEAT")
	private int avlSeat;
	
	//@Temporal(TemporalType.DATE)
	@Column(name="DATE_BOOKING")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern ="dd-MM-yyyy")
	private Date dateBook;

	@Column(name="SOURCE")
	private String source;

	@Column(name="FARE")
	private double fare;
	
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="BUS_ID")
	private Bus bus;
	
	

//	@OneToOne(fetch=FetchType.EAGER)
//	@JoinColumn(name="SEAT_ID")
//	private Seat seat;
	
	
	public Schedule() {
		
	}

	public Schedule(int scdulID, String busName, String destination, int duratn, int arriveTime, int deparTime,
			int totSeat, int bookSeat, int avlSeat, Date dateBook, int busID, String source, double fare, Bus bus) {
		super();
		this.scdulID = scdulID;
		
		this.destination = destination;
		this.duratn = duratn;
		this.arriveTime = arriveTime;
		this.deparTime = deparTime;
		this.totSeat = totSeat;
		this.bookSeat = bookSeat;
		this.avlSeat = avlSeat;
		this.dateBook = dateBook;
		
		this.source = source;
		this.fare = fare;
		this.bus = bus;
	}

	public int getScdulID() {
		return scdulID;
	}

	public void setScdulID(int scdulID) {
		this.scdulID = scdulID;
	}


	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getDuratn() {
		return duratn;
	}

	public void setDuratn(int duratn) {
		this.duratn = duratn;
	}

	public int getArriveTime() {
		return arriveTime;
	}

	public void setArriveTime(int arriveTime) {
		this.arriveTime = arriveTime;
	}

	public int getDeparTime() {
		return deparTime;
	}

	public void setDeparTime(int deparTime) {
		this.deparTime = deparTime;
	}

	public int getTotSeat() {
		return totSeat;
	}

	public void setTotSeat(int totSeat) {
		this.totSeat = totSeat;
	}

	public int getBookSeat() {
		return bookSeat;
	}

	public void setBookSeat(int bookSeat) {
		this.bookSeat = bookSeat;
	}

	public int getAvlSeat() {
		return avlSeat;
	}

	public void setAvlSeat(int avlSeat) {
		this.avlSeat = avlSeat;
	}


	public Date getDateBook() {
		return dateBook;
	}

	public void setDateBook(Date dateBook) {
		this.dateBook = dateBook;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public Bus getBus() {
		return bus;
	}

	public void setBus(Bus bus) {
		this.bus = bus;
	}

	@Override
	public String toString() {
		return "Schedule [scdulID=" + scdulID + ", destination=" + destination + ", duratn=" + duratn + ", arriveTime="
				+ arriveTime + ", deparTime=" + deparTime + ", totSeat=" + totSeat + ", bookSeat=" + bookSeat
				+ ", avlSeat=" + avlSeat + ", dateBook=" + dateBook + ", source=" + source + ", fare=" + fare + ", bus="
				+ bus + "]";
	}

	
	

	
	
	
}
