package com.lti.br.core.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="STOPS")
public class Stops {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_stop_seq")
	@SequenceGenerator(name = "my_stop_seq", sequenceName = "STOPS_SEQ", allocationSize = 1)
	@Column(name="STOP_ID")
	private int stopId;
	
	@Column(name="STOP_NAME")
	private String stopName;
	
	@Column(name="ARRIVAL_TIME")
	private String arrivalTime;
	
	@Column(name="DEPARTURE_TIME")
	private String departureTime;
	
	@Column(name="BUS_ID")
	//@JoinColumn(name="BUS_ID")
	private int busId;
	
	public Stops() {
		// TODO Auto-generated constructor stub
	}

	public Stops(int stopId, String stopName, String arrivalTime, String departureTime, int busId) {
		super();
		this.stopId = stopId;
		this.stopName = stopName;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.busId = busId;
	}

	public int getStopId() {
		return stopId;
	}

	public void setStopId(int stopId) {
		this.stopId = stopId;
	}

	public String getStopName() {
		return stopName;
	}

	public void setStopName(String stopName) {
		this.stopName = stopName;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}
	
}
