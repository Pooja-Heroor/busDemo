package com.lti.br.core.entities;

public class SearchDetails {
	private String busname;
	private String bustype;
	private int busno;
	private String source;
	private String destination;
	private double fare;
	
	
	public SearchDetails() {
		// TODO Auto-generated constructor stub
	}


	public SearchDetails(String busname, String bustype, int busno, String source, String destination, double fare) {
		super();
		this.busname = busname;
		this.bustype = bustype;
		this.busno = busno;
		this.source = source;
		this.destination = destination;
		this.fare = fare;
	}


	public String getBusname() {
		return busname;
	}


	public void setBusname(String busname) {
		this.busname = busname;
	}


	public String getBustype() {
		return bustype;
	}


	public void setBustype(String bustype) {
		this.bustype = bustype;
	}


	public int getBusno() {
		return busno;
	}


	public void setBusno(int busno) {
		this.busno = busno;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public double getFare() {
		return fare;
	}


	public void setFare(double fare) {
		this.fare = fare;
	}

	
}
