package com.lti.br.core.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="CUSTOMER")
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_cust_seq")
	@SequenceGenerator(name = "my_cust_seq", sequenceName = "cust_seq", allocationSize = 1)
	@Column(name="CUST_ID")
	private int custId;
	
	@Column(name="NAME")
	private String custName;
	
	@Column(name="EMAIL")
	private String custEmail;
	
	@Column(name="GENDER")
	private String gender;
	
	@Column(name="USERNAME")
	private String userName;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="MOBILENO")
	private long mobileNo;
	
//	@JsonIgnore
//	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
//	private List<Passenger> passengers;

	/*@JsonIgnore
	@OneToMany(mappedBy="bus",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Schedule> schedules;
*/
	public Customer() {
		// TODO Auto-generated constructor stub
	}


	public Customer(int custId, String custName, String custEmail, String gender, String userName, String password,
			long mobileNo, List<Passenger> passengers) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.gender = gender;
		this.userName = userName;
		this.password = password;
		this.mobileNo = mobileNo;
	
	}


	public int getCustId() {
		return custId;
	}


	public void setCustId(int custId) {
		this.custId = custId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getCustEmail() {
		return custEmail;
	}


	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public long getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}




	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", custEmail=" + custEmail + ", gender="
				+ gender + ", userName=" + userName + ", password=" + password + ", mobileNo=" + mobileNo
				+"]";
	}

	
	
}
