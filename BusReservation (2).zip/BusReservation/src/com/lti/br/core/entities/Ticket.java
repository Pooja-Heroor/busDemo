package com.lti.br.core.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TICKET_BOOKING")
public class Ticket {	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_ticket_seq")
	@SequenceGenerator(name = "my_ticket_seq", sequenceName = "TICK_SEQ", allocationSize = 1)
	@Column(name="BOOKING_ID")
	private int bookingId;
	 
	 @Column(name="SCHEDULE_ID")
	 //@JoinColumn(name="SCHEDULE_ID")
	private int scheduleId;
	 
	 @Column(name="CUST_ID")
	 //@JoinColumn(name="CUST_ID")
	private int customerId;
	 
	 @Column(name="BUS_ID")
	 //@JoinColumn(name="BUS_ID")
	private int busId;

	 public Ticket() {
		// TODO Auto-generated constructor stub
	}
	public Ticket(int bookingId, int scheduleId, int customerId, int busId) {
		super();
		this.bookingId = bookingId;
		this.scheduleId = scheduleId;
		this.customerId = customerId;
		this.busId = busId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	
	
	 
}
