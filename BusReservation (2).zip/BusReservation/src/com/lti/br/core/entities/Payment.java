package com.lti.br.core.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PAYMENT")
public class Payment {
		
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_pay_seq")
		@SequenceGenerator(name = "my_pay_seq", sequenceName = "PAY_SEQ", allocationSize = 1)
		@Column(name="TRANSACTION_ID")
		private int transactionId;
		
		@Column(name="PAYMENT_MODE")
		public String paymentMode;
		
		@Column(name="CUST_ID")
		//@JoinColumn(name="CUST_ID")
		public int custId;
		
		@Column(name="NAME")
		public String name;
		
		@Column(name="CARDNO")
		public int cardNo;
		
		@Column(name="EXPIREMONTH")
		public String expireMonth;
		
		@Column(name="CVV")
		public String cvv;
		
		public Payment() {
			// TODO Auto-generated constructor stub
		}

		public Payment(int transactionId, String paymentMode, int custId, String name, int cardNo, String expireMonth,
				String cvv) {
			super();
			this.transactionId = transactionId;
			this.paymentMode = paymentMode;
			this.custId = custId;
			this.name = name;
			this.cardNo = cardNo;
			this.expireMonth = expireMonth;
			this.cvv = cvv;
		}

		public int getTransactionId() {
			return transactionId;
		}

		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}

		public String getPaymentMode() {
			return paymentMode;
		}

		public void setPaymentMode(String paymentMode) {
			this.paymentMode = paymentMode;
		}

		public int getCustId() {
			return custId;
		}

		public void setCustId(int custId) {
			this.custId = custId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getCardNo() {
			return cardNo;
		}

		public void setCardNo(int cardNo) {
			this.cardNo = cardNo;
		}

		public String getExpireMonth() {
			return expireMonth;
		}

		public void setExpireMonth(String expireMonth) {
			this.expireMonth = expireMonth;
		}

		public String getCvv() {
			return cvv;
		}

		public void setCvv(String cvv) {
			this.cvv = cvv;
		}

		@Override
		public String toString() {
			return "Payment [transactionId=" + transactionId + ", paymentMode=" + paymentMode + ", custId=" + custId
					+ ", name=" + name + ", cardNo=" + cardNo + ", expireMonth=" + expireMonth + ", cvv=" + cvv + "]";
		}
		
}
