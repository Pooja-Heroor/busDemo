package com.lti.br.core.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ADMIN")
public class Admin {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_admin_seq")
	@SequenceGenerator(name = "my_admin_seq", sequenceName = "ADMIN_SEQ", allocationSize = 1)
	@Column(name="ADMIN_ID")
	private int adminId;
	
	@Column(name="PASSWORD")
	private String password; 
	
	public Admin() {
		// TODO Auto-generated constructor stub
	}

	public Admin(int adminId, String password) {
		super();
		this.adminId = adminId;
		this.password = password;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
