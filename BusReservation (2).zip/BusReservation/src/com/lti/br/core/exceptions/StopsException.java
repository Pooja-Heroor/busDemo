package com.lti.br.core.exceptions;

public class StopsException extends Exception {
	public StopsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		System.out.println("Error in Stops");
	}

	public StopsException(String arg0) {
		super(arg0);
	}
}
