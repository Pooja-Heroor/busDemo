package com.lti.br.core.exceptions;

public class SeatException extends Exception {
	public SeatException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public SeatException(String arg0) {
		super(arg0);
	}
}
