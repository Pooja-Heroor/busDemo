package com.lti.br.core.exceptions;

public class PassengerException extends Exception {

	public PassengerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		System.out.println("Passenger Exception");
	}

	public PassengerException(String arg0) {
		super(arg0);
	}

	
}
