package com.lti.br.core.exceptions;

public class TicketException extends Exception {
	public TicketException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public TicketException(String arg0) {
		super(arg0);
	}
}
