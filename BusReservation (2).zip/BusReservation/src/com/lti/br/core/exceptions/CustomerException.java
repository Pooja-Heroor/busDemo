package com.lti.br.core.exceptions;

public class CustomerException extends Exception {

	public CustomerException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

	public CustomerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}
	
	

}
